package org.feeds;

import com.mongodb.DBObject;
import com.mongodb.util.JSON;
import org.json.JSONObject;

public abstract class Feed {
    private String url;
    private int interval;
    private String response;
    private final String dateRegEx;
    private final String dateFormat;
    private final String[][] datePaths;


    protected Feed(String url, int interval, String dateFormat, String dateRegEx, String[][] datePaths) {
        this.url = url;
        this.interval = interval;
        this.dateFormat = dateFormat;
        this.dateRegEx = dateRegEx;
        this.datePaths = datePaths;
    }

    abstract void connect();

    abstract void getData();

    public String getUrl() {
        return url;
    }

    public int getInterval() {
        return interval;
    }

    public String getResponse() {
        return response;
    }

    protected void setUrl(String url) {
        this.url = url;
    }

    protected void setInterval(int interval) {
        this.interval = interval;
    }

    protected void setResponse(String response) {
        this.response = response;
    }

    protected DBObject extractDates(DBObject object) throws Exception {
        if (datePaths == null || datePaths.length < 1) {
            System.out.println("DATAPATH WAS NULL");
            return object;
        }

        for (String[] datePath : datePaths) {
            DBObject value = object;
            System.out.println(value.get(datePath[0]));



//            for (int i = 0; i < datePath.length-1; i++) {
//                String key = datePath[i];
//                value = (DBObject) value.get(key);
//            }
//
//            String key = datePath[datePath.length - 1];
//            Object d;
//
//            if (value.containsField(key)) {
//                for (String s : value.keySet()) {
//                    System.out.print("Keys: ");
//                    System.out.print(s);
//                    System.out.println();
//                }
//                d = value.get(key);
//            }
//            else {
//                System.out.println("Object was not found key: " + key + " value: " + value);
//                return object;
//            }
//
//            if (d == null) {
//                System.out.println("Object returned: " + key + " value: " + value);
//                return object;
//            }
//
//            if (d instanceof String) {
//                String date = (String) d;
//                System.out.println(date);
//            }
//            else {
//                System.out.println("name: " + d.getClass().getName());
//            }
        }
        
        return object;
    }

    protected DBObject extractDates(JSONObject jsonObject) throws Exception {
        DBObject object = (DBObject) JSON.parse(jsonObject.toString());
        return this.extractDates(object);
    }

}
