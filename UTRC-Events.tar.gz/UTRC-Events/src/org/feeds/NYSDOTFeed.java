package org.feeds;

import com.mongodb.DBCollection;

import java.util.HashMap;

public class NYSDOTFeed extends LoginFeed {
    private static final String url = "https://165.193.215.51/XMLFeeds/createXML.aspx";
    private static String dateFormat = "M/d/y h:m:s a";
    public static final String dateRegEx = "(\\d{1,2})[/](\\d{1,2})[/](\\d{2,4})\\s(\\d{1,2}):(\\d{2}):(\\d{2})?\\s(AM|PM)";

    public NYSDOTFeed(DBCollection collection,
                      String[] path,
                      String[][] datePaths,
                      int interval,
                      HashMap<String, String> postData) {

        super(url, collection, path, null, dateFormat, dateRegEx, datePaths, interval, postData);
    }
}
